# MyCollegeApp

In this repository, we are gonna talk about Designing Modern College Dashboard UI Adobe XD to Android Studio. In this section we will implementing like Constraint Layout, Grid Layout and Card View on Android Studio. The design would be look like this. If you want to see another topics, visit my personal blog. https://wp.me/p9eMR6-6D

<img src="http://abdulazizahwan.blog.unnes.ac.id/wp-content/uploads/sites/3025/2019/06/MyCollegeDashboard.png" width="200;"/>

## Part I [Design Section]
<a href="https://youtu.be/zeWnDlcNjQU" target="_blank"><img src="https://img.youtube.com/vi/zeWnDlcNjQU/maxresdefault.jpg"/></a>

## Part II [Code Section]
<a href="https://youtu.be/6jVedb2c-c8" target="_blank"><img src="https://img.youtube.com/vi/6jVedb2c-c8/maxresdefault.jpg"/></a>
